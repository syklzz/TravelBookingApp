export default class User{
    email: string;
    name: string;
    role: string;
    trips: string[];
    bought: any;
    rating: any;
}