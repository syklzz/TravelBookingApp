// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyCp6dfzNJcWfpL4ljKePvD5V_mEhKwRbb0",
    authDomain: "trips-8f0b7.firebaseapp.com",
    projectId: "trips-8f0b7",
    storageBucket: "trips-8f0b7.appspot.com",
    messagingSenderId: "643653972315",
    appId: "1:643653972315:web:09396f45ab75e0e8baea7e",
    measurementId: "G-N867J60262"
  }
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
